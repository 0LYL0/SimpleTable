//
//  ViewController.h
//  SimpleTable
//
//  Created by 刘雅兰 on 2017/3/17.
//  Copyright © 2017年 刘雅兰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>


@end

